#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
void gotoxy(int x, int y)
{
    COORD pos = {x, y};
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE); // 获取标准输出设备句柄
    SetConsoleCursorPosition(hOut, pos);           // 两个参数分别是指定哪个窗体，具体位置
}
// 隐藏光标
void HideCursor()
{
    CONSOLE_CURSOR_INFO curInfo;                     // 定义光标信息的结构体变量
    curInfo.dwSize = 1;                              // 如果没赋值的话，光标隐藏无效
    curInfo.bVisible = FALSE;                        // 将光标设置为不可见
    HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE); // 获取控制台句柄
    SetConsoleCursorInfo(handle, &curInfo);          // 设置光标信息
}

#define head 1
#define body 2
#define wall 3
#define kong 0
#define fu 4
struct
{ // 每一节蛇的坐标
    int x[10000];
    int y[10000];
    int len;   // 蛇长
    int speed; //
} snake;

int flag = 0;
int score = 0;
int width;
int height;
int Time = 0;
int game = 1;
char uname[20] = "undefine";
int level = 1;
char sustian = '1';
int position[27][71];
struct RECORD
{
    int Rscore;
    char Runame[20];
    int Rlevel;
    int RTime;
    char Rday[100];
    struct RECORD *next;
} record; // record[1000];

char MenuText[9][20] = {
    "[A]  Begin",
    "[B]  Username",
    "[C]  Gamedifficulty",
    "[D]  History data",
    "[E]  line",
    "[F]  Exit"};
void name()
{
    printf("Please enter your name: ");
    gets(uname);
    fflush(stdin);
}
void difficulty()
{
    printf("choose your gamedifficuty:\n");
    printf("1.simple(default) 2.middle 3.difficult\n");
    char key;
    scanf("%c", &key);
    fflush(stdin);
    if (key == '1')
    {
        level = 1;
        snake.speed = 1000;
    }
    else if (key == '2')
    {
        level = 2;
        snake.speed = 500;
    }
    else if (key == '3')
    {
        level = 3;
        snake.speed = 300;
    }
}
void history()
{
    system("chcp 65001");
    system("cls");
    printf("历史记录\n");
    FILE *fp1;
    fp1 = fopen("B.txt", "r");
    char getfrom[100];
    while (fgets(getfrom, sizeof(getfrom), fp1) != NULL)
    {
        // 输出每一行读取的字符串
        printf("%s", getfrom);
        printf("\n");
    }
    fclose(fp1);
    fp1 = NULL;
}

void displaymenu(int hilight)
{
    int i;
    printf("\n======================\n");
    for (i = 0; i < 6; i++)
    {
        if (i == hilight - 1)
            printf("<<%s>>\n", MenuText[i]);
        else
            printf("  %s\n", MenuText[i]);
    }
    printf("======================\n");
}

void drawMap()
{
    for (int i = 0; i <= height; i++)
    {
        position[i][0] = wall;
        gotoxy(0, i);
        printf("#");
        position[i][width] = wall;
        gotoxy(width, i);
        printf("#");
    }
    for (int i = 0; i <= width; i += 2) // 上下  #占用两个字符
    {
        position[0][i] = wall;
        position[0][i + 1] = wall;
        gotoxy(i, 0);
        printf("#");
        position[height][i] = wall;
        position[height][i + 1] = wall;
        gotoxy(i, height);
        printf("#");
    }

    snake.len = 0;
    snake.x[0] = width / 2; // 开始蛇头放屏幕中间
    snake.y[0] = height / 2;
    position[snake.y[0]][snake.x[0]] = head;
    gotoxy(snake.x[0], snake.y[0]);

    printf("@");
}
// 随机生成食物
void Food()
{
    int i, j;
    do
    {
        // 随机生成食物的横纵坐标
        i = rand() % (height - 1) + 1;
        j = rand() % (width - 1) + 1;
        if (j % 2 == 0)
            j++;
    } while (position[i][j] != kong); // 确保生成食物的位置为空，若不为空则重新生成
    position[i][j] = fu; // 将食物位置进行标记
    gotoxy(j, i);
    printf("$"); // 打印食物
}

void add(int tx, int ty)
{
    snake.len++;
    snake.x[snake.len] = tx; // 新加的身体x轴方向等于前一节身体
    snake.y[snake.len] = ty;
    position[snake.y[snake.len]][snake.x[snake.len]] = body; // 给新加的身体标记
    gotoxy(snake.x[snake.len], snake.y[snake.len]);

    printf("*");
}

void move()
{
    for (int i = 0; i <= height; i++)
    {
        for (int j = 0; j <= width; j++)
        {
            if (position[i][j] == 0)
            {
                gotoxy(j, i);
                printf(" ");
            }
        }
    }
}

void prints()
{
    for (int i = 0; i <= snake.len; i++)
    {
        gotoxy(snake.x[i], snake.y[i]);
        if (i == 0)
        {

            printf("@");
        }
        else
            printf("*");
    }
}

void check(int tx, int ty)
{
    if (position[snake.y[0]][snake.x[0]] == fu)
    {
        add(tx, ty);
        score += 10;
        gotoxy(0, height + 1);
        printf(" recent score:%d", score);
        flag = 1;
    }
}
void Read()
{
    FILE *pf = fopen("B.txt", "a+"); // 以追加的方式打开文件
    char day[20];
    printf("\n");
    fprintf(pf, " ");
    fprintf(pf, "%d ", score);
    fprintf(pf, " ");
    fprintf(pf, "%s ", uname);
    fprintf(pf, " ");
    fprintf(pf, "%d ", level);
    fprintf(pf, " ");
    fprintf(pf, "%d", Time);
    time_t t;
    struct tm dt;
    time(&t);
    localtime_s(&dt, &t);
    fprintf(pf, " ");
    snprintf(day, sizeof(day), "%04d-%02d-%02d.%02d:%02d:%02d",
             dt.tm_year + 1900, dt.tm_mon + 1, dt.tm_mday,
             dt.tm_hour, dt.tm_min, dt.tm_sec);
    fprintf(pf, "%s", day);
    fflush(pf);
    fclose(pf); // 关闭文件
    pf = NULL;  // 文件指针及时置空
}

void Mline()
{
    printf("Enter the month(9->09):");
    char month[3];
    scanf("%s", month);
    fflush(stdin);
    system("chcp 65001");
    system("cls");
    printf("月排行榜\n");
    printf("得分 | 用户名 | 难度 | 游戏时长(ms) | 游戏时间日期 |");
    int lscore;
    char luname[20];
    int llevel;
    int lTime;
    char lday[100];
    struct RECORD *header = (struct RECORD *)malloc(sizeof(struct RECORD));
    header->next = NULL;
    struct RECORD *p = header;
    FILE *pfr = fopen("B.txt", "r");
    while (fscanf(pfr, "%d %s %d %d %s ", &lscore, luname, &llevel, &lTime, lday) == 5)
    {
        if (lday[5] == month[0] && lday[6] == month[1])
        {
            struct RECORD *new = (struct RECORD *)malloc(sizeof(struct RECORD));
            p->next = new;
            new->next = NULL;
            new->Rscore = lscore;
            strcpy(new->Runame, luname);
            new->Rlevel = llevel;
            new->RTime = lTime;
            strcpy(new->Rday, lday);
            p = p->next;
        }
    }
    fclose(pfr);
    pfr = NULL;
    if (header == NULL || header->next == NULL)
    {
        return; // 空链表或只有一个元素，不需要排序
    }

    struct RECORD *count, *advance, *pre, *end;
    int swapped;

    do
    {
        swapped = 0; // 用于检查本轮是否发生了交换
        count = header;
        pre = NULL;
        advance = header;
        end = advance->next;

        while (end != NULL)
        {
            // 比较相邻两个节点的 Rscore 值
            if (advance->Rscore < end->Rscore)
            {
                // 交换节点
                if (pre != NULL)
                {
                    pre->next = end; // 前一个节点指向后一个节点
                }
                else
                {
                    header = end; // 如果交换的是头节点，更新头指针
                }
                advance->next = end->next; // advance 指向 end 的下一个节点
                end->next = advance;       // end 指向 advance

                // 更新指针以继续遍历
                swapped = 1;         // 标记发生了交换
                pre = end;           // 更新 pre 为 end
                end = advance->next; // 更新 end 为 advance 的下一个节点
            }
            else
            {
                pre = advance;   // 更新 pre 为 advance
                advance = end;   // 更新 advance 为 end
                end = end->next; // 更新 end 为 end 的下一个节点
            }
        }
    } while (swapped); // 如果本轮没有发生交换，说明排序完成
    printf("\n");
    for (header = header->next; header != NULL; header = header->next)
    {
        printf("%d %s %d %d %s\n", header->Rscore, header->Runame, header->Rlevel, header->RTime, header->Rday);
    }
}
void Yline()
{
    printf("Enter the year:");
    char year[5];
    scanf("%s", year);
    fflush(stdin);
    system("chcp 65001");
    system("cls");
    printf("年排行榜\n");
    printf("得分 | 用户名 | 难度 | 游戏时长(ms) | 游戏时间日期 |");
    int lscore;
    char luname[20];
    int llevel;
    int lTime;
    char lday[100];
    struct RECORD *header = (struct RECORD *)malloc(sizeof(struct RECORD));
    header->next = NULL;
    struct RECORD *p = header;
    FILE *pfr = fopen("B.txt", "r");
    while (fscanf(pfr, "%d %s %d %d %s ", &lscore, luname, &llevel, &lTime, lday) == 5)
    {
        if (lday[0] == year[0] && lday[1] == year[1] && lday[2] == year[2] && lday[3] == year[3])
        {
            struct RECORD *new = (struct RECORD *)malloc(sizeof(struct RECORD));
            p->next = new;
            new->next = NULL;
            new->Rscore = lscore;
            strcpy(new->Runame, luname);
            new->Rlevel = llevel;
            new->RTime = lTime;
            strcpy(new->Rday, lday);
            p = p->next;
        }
    }
    fclose(pfr);
    pfr = NULL;
    if (header == NULL || header->next == NULL)
    {
        return; // 空链表或只有一个元素，不需要排序
    }

    struct RECORD *count, *advance, *pre, *end;
    int swapped;

    do
    {
        swapped = 0; // 用于检查本轮是否发生了交换
        count = header;
        pre = NULL;
        advance = header;
        end = advance->next;

        while (end != NULL)
        {
            // 比较相邻两个节点的 Rscore 值
            if (advance->Rscore < end->Rscore)
            {
                // 交换节点
                if (pre != NULL)
                {
                    pre->next = end; // 前一个节点指向后一个节点
                }
                else
                {
                    header = end; // 如果交换的是头节点，更新头指针
                }
                advance->next = end->next; // advance 指向 end 的下一个节点
                end->next = advance;       // end 指向 advance

                // 更新指针以继续遍历
                swapped = 1;         // 标记发生了交换
                pre = end;           // 更新 pre 为 end
                end = advance->next; // 更新 end 为 advance 的下一个节点
            }
            else
            {
                pre = advance;   // 更新 pre 为 advance
                advance = end;   // 更新 advance 为 end
                end = end->next; // 更新 end 为 end 的下一个节点
            }
        }
    } while (swapped); // 如果本轮没有发生交换，说明排序完成
    printf("\n");
    for (header = header->next; header != NULL; header = header->next)
    {
        printf("%d %s %d %d %s\n", header->Rscore, header->Runame, header->Rlevel, header->RTime, header->Rday);
    }
}

void line()
{

    char what;
    printf("YEAR or MONTH ?");
    printf("press Y or M");
    scanf("%c", &what);
    fflush(stdin);
    if (what == 'Y')
    {
        system("cls");
        Yline();
    }
    else
    {
        system("cls");
        Mline();
    }
}

int ifsafe()
{

    if (snake.y[0] == 0 || snake.y[0] == height || snake.x[0] < 0 || snake.x[0] > width || position[snake.y[0]][snake.x[0]] == body) // 直接使用索引判断是否撞到墙
    {
        Read();
        system("cls");
        printf("Failure\n");
        printf("\n======================\n");
        printf("Do you still continue?");
        printf("\n======================\n");
        printf("if yes , press '1'\n");
        printf("if no , press '0'\n");
        sustian = getch(); // 判断是否继续 使用getch避免了scanf必须按下'\r'的问题 此处注意输入的数会转换成字符串
        fflush(stdin);
        if (sustian == '1')
        {
            system("cls");
            game = 0;
            for (int i = 0; i <= height; i++)
            {
                for (int j = 0; j <= width; j++)
                {
                    position[i][j] = kong;
                }
            } // 清空掉之前的标记
            return 1;
        }
        else
            exit(0);
    }
    else
        return 0;
}

void GAME()
{
    if (level == 1)
    {
        height = 14;
        width = 30;
    }
    else if (level == 2)
    {
        height = 20;
        width = 50;
    }
    else if (level == 3)
    {
        height = 26;
        width = 70;
    }
    HideCursor();
    int x, y;
    char key = 'w';
    system("cls");
    drawMap();
    Food();
    for (; game;)
    {
        gotoxy(0, height + 1);
        printf(" recent score:%d", score);
        switch (key)
        {
        case 'W': // 往上走 y--
        case 'w':
            for (; game;)
            {
                if (kbhit())
                {
                    key = getch();
                    fflush(stdin); // 防止多按
                    if (key != 'w' && key != 'W')
                    {
                        break;
                    }
                } // 进行下一次循环时先判断才能及时转换蛇头的方向
                if (Time % (snake.speed * 15) == 0)
                {
                    Food();
                }
                Time += snake.speed; // 蛇每次移动需要的时间
                if (flag)
                {
                    for (int i = snake.len; i >= 0; i--) // 从蛇尾开始打印
                    {
                        if (i == 0)
                        {
                            int tx = snake.x[i];
                            int ty = snake.y[i];
                            snake.y[i]--;
                            check(tx, ty);

                            if (ifsafe())
                                break;
                            else
                                position[snake.y[i]][snake.x[i]] = head;
                        }
                        else
                        {
                            if (i == snake.len) // 如果是蛇尾
                            {
                                position[snake.y[i]][snake.x[i]] = kong; // 清除掉蛇尾
                            }
                            snake.x[i] = snake.x[i - 1];
                            snake.y[i] = snake.y[i - 1];
                            position[snake.y[i]][snake.x[i]] = body;
                        }
                    }
                    move();
                    if (game)
                        prints(); // 加上if修复小bug(避免当游戏失败重启后多打印了)
                }
                else
                {
                    position[snake.y[0]][snake.x[0]] = kong;
                    move();
                    int tx = snake.x[0];
                    int ty = snake.y[0];
                    snake.y[0]--;
                    check(tx, ty);

                    if (ifsafe())
                        break;
                    else
                        position[snake.y[0]][snake.x[0]] = head;
                    gotoxy(snake.x[0], snake.y[0]);
                    if (game)
                    {

                        printf("@");
                    }
                }
                Sleep(snake.speed);
            }
            break;
        case 'S':
        case 's':
            for (; game;)
            {
                if (kbhit())
                {
                    key = getch();
                    fflush(stdin);
                    if (key != 's' && key != 'S')
                    {
                        break;
                    }
                }
                if (Time % (snake.speed * 15) == 0)
                {
                    Food();
                }
                Time += snake.speed;
                if (flag)
                {
                    for (int i = snake.len; i >= 0; i--)
                    {
                        if (i == 0)
                        {
                            int tx = snake.x[i];
                            int ty = snake.y[i];
                            snake.y[i]++;
                            check(tx, ty);

                            if (ifsafe())
                                break;
                            else
                                position[snake.y[i]][snake.x[i]] = head;
                        }
                        else
                        {
                            if (i == snake.len)
                            {
                                position[snake.y[i]][snake.x[i]] = kong;
                            }
                            snake.x[i] = snake.x[i - 1];
                            snake.y[i] = snake.y[i - 1];
                            position[snake.y[i]][snake.x[i]] = body;
                        }
                    }
                    move();
                    if (game)
                        prints();
                }
                else
                {
                    position[snake.y[0]][snake.x[0]] = kong;
                    move();
                    int tx = snake.x[0];
                    int ty = snake.y[0];
                    snake.y[0]++;
                    check(tx, ty);

                    if (ifsafe())
                        break;
                    else
                        position[snake.y[0]][snake.x[0]] = head;
                    gotoxy(snake.x[0], snake.y[0]);
                    if (game)
                    {

                        printf("@");
                    }
                }

                Sleep(snake.speed);
            }
            break;
        case 'A':
        case 'a':
            for (; game;)
            {
                if (kbhit())
                {
                    key = getch();
                    fflush(stdin);
                    if (key != 'a' && key != 'A')
                    {
                        break;
                    }
                }
                if (Time * 1000 % (snake.speed * 5) == 0)
                {
                    Food();
                }
                Time += snake.speed;
                if (flag)
                {
                    for (int i = snake.len; i >= 0; i--)
                    {
                        if (i == 0)
                        {
                            int tx = snake.x[i];
                            int ty = snake.y[i];
                            snake.x[i] -= 2;
                            check(tx, ty);

                            if (ifsafe())
                                break;
                            else
                                position[snake.y[i]][snake.x[i]] = head;
                        }
                        else
                        {
                            if (i == snake.len)
                            {
                                position[snake.y[i]][snake.x[i]] = kong;
                            }
                            snake.x[i] = snake.x[i - 1];
                            snake.y[i] = snake.y[i - 1];
                            position[snake.y[i]][snake.x[i]] = body;
                        }
                    }
                    move();
                    if (game)
                        prints();
                }
                else
                {
                    position[snake.y[0]][snake.x[0]] = kong;
                    move();
                    int tx = snake.x[0];
                    int ty = snake.y[0];
                    snake.x[0] -= 2;
                    check(tx, ty);

                    if (ifsafe())
                        break;
                    else
                        position[snake.y[0]][snake.x[0]] = head;
                    gotoxy(snake.x[0], snake.y[0]);
                    if (game)
                    {

                        printf("@");
                    }
                }
                Sleep(snake.speed);
            }
            break;
        case 'd':
        case 'D':
            for (; game;)
            {
                if (kbhit())
                {
                    key = getch();
                    fflush(stdin);
                    if (key != 'd' && key != 'D')
                    {
                        break;
                    }
                }
                if (Time % (snake.speed * 15) == 0)
                {
                    Food();
                }
                Time += snake.speed;
                if (flag)
                {
                    for (int i = snake.len; i >= 0; i--)
                    {
                        if (i == 0)
                        {
                            int tx = snake.x[i];
                            int ty = snake.y[i];
                            snake.x[i] += 2;
                            check(tx, ty);

                            if (ifsafe())
                                break;
                            else
                                position[snake.y[i]][snake.x[i]] = head;
                        }
                        else
                        {
                            if (i == snake.len)
                            {
                                position[snake.y[i]][snake.x[i]] = kong;
                            }
                            snake.x[i] = snake.x[i - 1];
                            snake.y[i] = snake.y[i - 1];
                            position[snake.y[i]][snake.x[i]] = body;
                        }
                    }

                    move();
                    if (game)
                        prints();
                }
                else
                {
                    position[snake.y[0]][snake.x[0]] = kong;
                    move();
                    int tx = snake.x[0];
                    int ty = snake.y[0];
                    snake.x[0] += 2;
                    check(tx, ty);

                    if (ifsafe())
                        break;
                    else
                        position[snake.y[0]][snake.x[0]] = head;
                    gotoxy(snake.x[0], snake.y[0]);
                    if (game)
                    {

                        printf("@");
                    }
                }
                Sleep(snake.speed);
            }
            break;
        }
    }
}

void start()
{
    int sel = 1;
    snake.speed = 1000;
    system("cls");
    displaymenu(1);
    for (; game;)
    {
        if (kbhit())
        {
            if (GetAsyncKeyState(VK_UP))
            { // 判断是否<上>按键点击
                sel = (sel > 1) ? sel - 1 : sel;
                system("cls");    // 清屏
                displaymenu(sel); // 显示菜单
                getch();
                getch();
            }
            else if (GetAsyncKeyState(VK_DOWN))
            { // 判断是否<下>按键点击
                sel = (sel < 6) ? sel + 1 : sel;
                system("cls");
                displaymenu(sel);
                getch();
                getch();
            }
            else
            {
                char c = getch();
                fflush(stdin);
                if (c == '\r')
                {
                    switch (sel)
                    {
                    case 1:
                        GAME();
                        break;
                    case 2:
                        name();
                        break;
                    case 3:
                        difficulty();
                        break;
                    case 4:
                        history();
                        break;
                    case 5:
                        line();
                        break;
                    case 6:
                        exit(0);
                    default:
                        break;
                    }
                }
                else
                {
                    switch (c)
                    {
                    case 'A':
                        sel = c - 16 - '0'; // 将按键转化成对应的数字
                        system("cls");
                        displaymenu(sel);
                        GAME();
                        break;
                    case 'B':
                        sel = c - 16 - '0';
                        system("cls");
                        displaymenu(sel);
                        name();
                        break;
                    case 'C':
                        sel = c - 16 - '0';
                        system("cls");
                        displaymenu(sel);
                        difficulty();
                        break;
                    case 'D':
                        sel = c - 16 - '0';
                        system("cls");
                        displaymenu(sel);
                        history();
                        break;
                    case 'E':
                        sel = c - 16 - '0';
                        system("cls");
                        displaymenu(sel);
                        line();
                        break;
                    case 'F':
                        exit(0);
                    default:
                        break;
                    }
                }
            }
        }
    }
}
int main()
{
    system("title Snake Game");
    while (sustian == '1')
    {
        system("color 4e");
        score = 0;
        Time = 0;
        game = 1;
        level = 1;
        flag = 0; // 记得更新一些条件，防止再次进入游戏遗留变量
        start();
    }
    return 0;
}
